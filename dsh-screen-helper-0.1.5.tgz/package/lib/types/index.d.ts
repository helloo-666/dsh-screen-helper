/**
 * dsh-screen-helper — a DeepSeek Harness bundle that drives the
 * ScreenAutomationHelper CLI (屏幕自动化小助手) from the model.
 *
 * Design notes that matter:
 *
 *  - ONE tool, not forty. The CLI exposes ~42 capability families. Registering
 *    one tool per subcommand would flood the model's tool list. Instead a single
 *    `screen_automation` tool takes an `action` enum plus a free-form `args`
 *    array, and its description carries the usage manual. This keeps the tool
 *    namespace small while still reaching the whole CLI.
 *
 *  - Risk tiers are computed BEFORE execution (`classify`). Read-only and
 *    screen-observation calls run directly; anything that moves the mouse,
 *    types, or mutates workflows is `mutate` and can require approval.
 *
 *  - Approval is fail-closed by construction: `ctx.approval.request` resolves
 *    'unavailable' when nobody answers, so an unattended session cannot
 *    accidentally drive the screen.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "screen-helper";
export declare const inject: string[];
/** Plugin configuration, validated and defaulted by Cordis via the schema. */
/**
 * How much of the surface requires user approval before running.
 *
 * - `always`   — every call, including read-only ones, asks first.
 * - `mutating` — only actions that can move the mouse, type, or change state ask.
 * - `never`    — nothing asks; the model runs everything.
 */
export type ApprovalMode = 'always' | 'mutating' | 'never';
/**
 * How the plugin itself gates screen-mutating actions when dsh's native
 * approval popup is unavailable (e.g. in sessions where approval prompts are
 * disabled and fail closed). The plugin renders its own confirmation card
 * instead of relying on the host's popup.
 *
 * - `popup` — every mutate shows a confirmation card (with the target app's
 *   icon + name) before running; the real action executes only after the user
 *   approves the returned token.
 * - `off`    — the plugin runs mutate actions directly (no plugin-side gate).
 */
export type ConfirmMode = 'popup' | 'off';
export interface Config {
    cliPath: string;
    timeoutMs: number;
    approval: ApprovalMode;
    confirm: ConfirmMode;
    blockDestructive: boolean;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
