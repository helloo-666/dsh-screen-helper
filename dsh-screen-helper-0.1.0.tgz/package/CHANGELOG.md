# Changelog

## 0.1.0

Initial release.

- `screen_automation` tool driving the ScreenAutomationHelper CLI: read, observe, and mutate
  action tiers covering ~42 capability families.
- Shell-free invocation: arguments are passed as a real `argv` array, so shell metacharacters
  are inert.
- Risk-tier classification with fail-safe defaulting of unknown subcommands to `mutate`.
- Three approval modes: `always` (every call prompts), `mutating` (only state-changing calls
  prompt), and `never` (nothing prompts; the default).
- Approval via dsh's fail-closed approval service: a missing answerer, a cancellation, a
  throwing answerer, or an unrecognized return value all deny.
- Optional `blockDestructive` hard block for workflow mutation and clipboard writes.
- Per-invocation timeout with cancellation forwarding.
- 29 tests across classification, real-CLI behaviour, plugin registration, and the approval
  vocabulary.

### Fixed before first release

- **The approval gate never granted anything.** The gate compared the answerer's outcome against
  `'approved'`, but dsh's grant token is `'allowed-once'` (its closed vocabulary is
  `allowed-once | rejected | cancelled | unavailable`). Every approved action was therefore
  denied — the feature was inert. The comparison now targets the grant token, so an
  unrecognized outcome denies instead of being confused with a grant. A regression test pins the
  whole vocabulary, including the near-miss strings (`'approved'`, `'allowed'`,
  `'ALLOWED-ONCE'`) that must all deny.

  This was invisible to the original tests because those tests used the same wrong string the
  implementation did; the contract only surfaced when reading `dsh-user-approval`'s source.
