/**
 * ScreenAutomationHelper CLI invocation core.
 *
 * Responsibilities, in order of importance:
 *   1. Classify a requested subcommand into a risk tier BEFORE it runs.
 *   2. Build an argv array — never a shell string — so a hostile argument can
 *      never become a second command.
 *   3. Spawn with a timeout and forward cancellation.
 *   4. Parse the tool's JSON envelope, tolerating the fact that some
 *      subcommands print non-JSON human text.
 *
 * Everything here is deliberately free of Cordis imports so it stays testable
 * with plain `node --test`.
 */
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
/** Risk tier of one CLI subcommand path. */
export type RiskTier = 
/** Reads product state or files; cannot change the machine. */
'read'
/** Observes the screen or UI tree; reveals screen content but does not act. */
 | 'observe'
/** Moves the mouse, types, writes the clipboard, or mutates workflows. */
 | 'mutate';
/** One CLI invocation: a subcommand path plus its flags. */
export interface CliInvocation {
    /** Subcommand path, e.g. `['screen', 'capture']`. */
    readonly path: readonly string[];
    /** Flags and positionals, already split into argv elements. */
    readonly args?: readonly string[];
}
/** Successful CLI outcome. */
export interface CliSuccess {
    readonly ok: true;
    /** Raw stdout text. */
    readonly stdout: string;
    /** Parsed JSON value when stdout parsed as JSON, else undefined. */
    readonly json: JsonValue | undefined;
    /** Process exit code (0 here). */
    readonly exitCode: 0;
}
/** Failed CLI outcome; never thrown, so callers decide the tool-level error. */
export interface CliFailure {
    readonly ok: false;
    /** Machine-readable failure code. */
    readonly code: 'SPAWN_FAILED' | 'TIMEOUT' | 'CANCELLED' | 'NONZERO_EXIT';
    /** Human-readable explanation, safe to surface to the model. */
    readonly message: string;
    readonly stdout: string;
    readonly stderr: string;
    readonly exitCode: number | null;
}
export type CliOutcome = CliSuccess | CliFailure;
/**
 * Everything not listed above is treated as `mutate`. This is a fail-safe
 * default: a subcommand added by a future CLI version is gated rather than
 * silently allowed.
 */
export declare function classify(path: readonly string[]): RiskTier;
export declare function isDestructive(path: readonly string[]): boolean;
/**
 * Reject arguments that would confuse argv construction. Since we never use a
 * shell this is defense in depth rather than the primary control, but a NUL or
 * newline in an argument indicates a caller bug or an injection attempt.
 */
export declare function assertSafeArgs(args: readonly string[]): void;
/** Options for {@link runCli}. */
export interface RunCliOptions {
    /** Absolute path to the helper executable. */
    readonly cliPath: string;
    /** Invocation to perform. */
    readonly invocation: CliInvocation;
    /** Milliseconds before the child is killed. */
    readonly timeoutMs: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
    /** Working directory; the helper expects its own install dir. */
    readonly cwd?: string;
}
/** Resolve the executable to spawn, honoring an explicit path over PATH lookup. */
export declare function resolveCliPath(configured: string): string;
/**
 * Run one CLI invocation and normalize the outcome.
 *
 * Never throws for an expected failure (spawn error, timeout, cancellation,
 * non-zero exit) — those come back as a {@link CliFailure} so the tool body can
 * render them as an ordinary error result.
 */
export declare function runCli(options: RunCliOptions): Promise<CliOutcome>;
/** Parse stdout as JSON when possible; return undefined for plain text. */
export declare function tryParseJson(text: string): JsonValue | undefined;
/** Render a JSON value into a compact, model-friendly text block. */
export declare function stringifyForModel(value: unknown): string;
