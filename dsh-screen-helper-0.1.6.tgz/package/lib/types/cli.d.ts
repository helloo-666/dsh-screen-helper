/**
 * ScreenAutomationHelper CLI invocation core.
 *
 * Responsibilities, in order of importance:
 *   1. Classify a requested subcommand into a risk tier BEFORE it runs.
 *   2. Build an argv array — never a shell string — so a hostile argument can
 *      never become a second command.
 *   3. Spawn with a timeout and forward cancellation.
 *   4. Parse the tool's JSON envelope, tolerating the fact that some
 *      subcommands print non-JSON human text.
 *
 * Everything here is deliberately free of Cordis imports so it stays testable
 * with plain `node --test`.
 */
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
/** Risk tier of one CLI subcommand path. */
export type RiskTier = 
/** Reads product state or files; cannot change the machine. */
'read'
/** Observes the screen or UI tree; reveals screen content but does not act. */
 | 'observe'
/** Moves the mouse, types, writes the clipboard, or mutates workflows. */
 | 'mutate';
/** One CLI invocation: a subcommand path plus its flags. */
export interface CliInvocation {
    /** Subcommand path, e.g. `['screen', 'capture']`. */
    readonly path: readonly string[];
    /** Flags and positionals, already split into argv elements. */
    readonly args?: readonly string[];
}
/** Successful CLI outcome. */
export interface CliSuccess {
    readonly ok: true;
    /** Raw stdout text. */
    readonly stdout: string;
    /** Parsed JSON value when stdout parsed as JSON, else undefined. */
    readonly json: JsonValue | undefined;
    /** Process exit code (0 here). */
    readonly exitCode: 0;
}
/** Failed CLI outcome; never thrown, so callers decide the tool-level error. */
export interface CliFailure {
    readonly ok: false;
    /** Machine-readable failure code. */
    readonly code: 'SPAWN_FAILED' | 'TIMEOUT' | 'CANCELLED' | 'NONZERO_EXIT';
    /** Human-readable explanation, safe to surface to the model. */
    readonly message: string;
    readonly stdout: string;
    readonly stderr: string;
    readonly exitCode: number | null;
}
export type CliOutcome = CliSuccess | CliFailure;
/**
 * Everything not listed above is treated as `mutate`. This is a fail-safe
 * default: a subcommand added by a future CLI version is gated rather than
 * silently allowed.
 */
export declare function classify(path: readonly string[]): RiskTier;
export declare function isDestructive(path: readonly string[]): boolean;
/**
 * Reject arguments that would confuse argv construction. Since we never use a
 * shell this is defense in depth rather than the primary control, but a NUL or
 * newline in an argument indicates a caller bug or an injection attempt.
 */
export declare function assertSafeArgs(args: readonly string[]): void;
/** Options for {@link runCli}. */
export interface RunCliOptions {
    /** Absolute path to the helper executable. */
    readonly cliPath: string;
    /** Invocation to perform. */
    readonly invocation: CliInvocation;
    /** Milliseconds before the child is killed. */
    readonly timeoutMs: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
    /** Working directory; the helper expects its own install dir. */
    readonly cwd?: string;
}
/** Resolve the executable to spawn, honoring an explicit path over PATH lookup. */
export declare function resolveCliPath(configured: string): string;
/**
 * Run one CLI invocation and normalize the outcome.
 *
 * Never throws for an expected failure (spawn error, timeout, cancellation,
 * non-zero exit) — those come back as a {@link CliFailure} so the tool body can
 * render them as an ordinary error result.
 */
export declare function runCli(options: RunCliOptions): Promise<CliOutcome>;
/** Parse stdout as JSON when possible; return undefined for plain text. */
export declare function tryParseJson(text: string): JsonValue | undefined;
/** Render a JSON value into a compact, model-friendly text block. */
export declare function stringifyForModel(value: unknown): string;
/**
 * One word-level OCR hit, exactly as `screen.recognize` emits it.
 * Kept structural so the tool layer can pass it through unchanged.
 */
export interface OcrItem {
    readonly text: string;
    readonly confidence: number;
    /** [x1, y1, x2, y2] in screen pixels. */
    readonly box: readonly number[];
    /** [cx, cy] — box center. */
    readonly center: readonly number[];
}
/** Resolved foreground-application identity, including an extracted icon file. */
export interface AppInfo {
    /** Process name, e.g. "Notepad.exe". */
    readonly process: string | null;
    /** Window title text. */
    readonly title: string | null;
    /** Absolute path to the process executable. */
    readonly exe: string | null;
    /** Display name: process minus extension, or title if unknown. */
    readonly displayName: string;
    /** Path to a PNG icon extracted from the executable, or null if unavailable. */
    readonly iconPath: string | null;
}
/**
 * Resolve the foreground application and extract its icon to a PNG.
 *
 * Used so the model — and the human approving a mutate — can *see which app* is
 * about to be operated, not just read a process name. The icon is pulled from the
 * executable via Windows `System.Drawing.Icon.ExtractAssociatedIcon`; on non-Windows
 * hosts (or when extraction fails) `iconPath` is null and the textual identity is
 * still returned. The icon file lives under the system temp dir.
 */
export declare function resolveForegroundApp(cliPath: string, timeoutMs: number, signal?: AbortSignal): Promise<AppInfo>;
/**
 * Deliver one screen input WITHOUT moving the physical cursor.
 *
 * Delegates to `scripts/background-input.ps1`, which sends Win32 messages
 * straight to the target window's child control. Returns the script's JSON
 * envelope, notably `cursorMoved` — the caller is expected to surface that so a
 * "background" operation can never silently become a cursor grab.
 *
 * Returns null when the script cannot be located or produces no JSON.
 */
export declare function runBackgroundInput(params: {
    action: 'click' | 'type' | 'key';
    x?: number;
    y?: number;
    text?: string;
    key?: number;
    title?: string;
    hwnd?: number;
    timeoutMs: number;
}): Promise<Record<string, unknown> | null>;
/**
 * Find precise word-level boxes for `query` within OCR `items`.
 *
 * `screen.find` returns the *line* containing a hit, which is too coarse to
 * click a small control. `screen.recognize` returns one box per recognized
 * token, so a substring match against those tokens yields a box that actually
 * covers the target text.
 *
 * Ranking: exact-token matches first, then **shortest containing token**
 * (a UI control label is the minimal text that contains the query, while a
 * chat log line merely happens to contain it), then by confidence. The
 * shortest-first rule matters when no token equals the query exactly — e.g.
 * the query "新会话" against a sidebar button rendered as "④新会话" (icon
 * prefix, conf 0.88) plus long chat lines quoting "新会话" (conf 0.97+):
 * confidence alone would pick a chat line and click the wrong place.
 */
export declare function findExact(items: readonly OcrItem[], query: string): {
    query: string;
    count: number;
    matches: OcrItem[];
};
